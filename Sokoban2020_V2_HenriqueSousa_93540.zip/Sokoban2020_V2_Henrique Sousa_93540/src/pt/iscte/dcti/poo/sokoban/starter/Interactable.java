package pt.iscte.dcti.poo.sokoban.starter;

public interface Interactable {

	public boolean isInteractable();
	public void interact(Objects obj);
}
